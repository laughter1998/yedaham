<?php 
//$email = "yedaham@thekyedaham.co.kr";  // 받는사람 이메일
//$email2 = "shtop1@naver.com";  // 받는사람 이메일
//$email3 = "hsk00@purpleroute.co.kr";  // 받는사람 이메일
//"김준혁"<jun162543@thekyedaham.co.kr>
//"홍승만"<seungmanhong@thekyedaham.co.kr>
$email = "symoon10@thekyedaham.co.kr";  // 받는사람 이메일 인사팀장님 
$email2 = "nine0659@thekyedaham.co.kr";  
$email3 = "hkim@thekyedaham.co.kr";  // 받는사람 이메일 감사팀장


$captcha = $_POST['g-recaptcha-response'];
$secretKey = "6Lfs0w4aAAAAAGhj-C3xVbFFrVWeR49ggA0M0eQu";
$ip = $_SERVER['REMOTE_ADDR'];


$data = array(
  'secret' => $secretKey,
  'response' => $captcha,
  'ip' => $ip
);
$parameter = http_build_query($data);
$url = "https://www.google.com/recaptcha/api/siteverify?".$parameter;

$response = file_get_contents($url);
$responseKeys = json_decode($response, true);

if ($responseKeys["success"]) { //캡챠 성공시


	$title = "불공정행위익명제보";
	$title = "=?UTF-8?B?".base64_encode($title)."?=";

	//$add_mailheader ="From:예다함<theklife@theklife.co.kr>\n";
	$add_mailheader ="From:Yedaham<theklife@theklife.co.kr>\n";
	$add_mailheader.="Reply-To: theklife@theklife.co.kr\n";
	$add_mailheader.="Content-Type: text/html;charset=UTF-8";
	$date14 = date("YmdHis",time());


	$img_no = array("html", "htm", "php", "js", "jsp", "asp");
	$mime_no = array("text/plain", "text/html", "application/octet-stream", "text/css");
	 
	$attach1_ = "";
		if ($_FILES['attach1']['name']){
			if ($_FILES['attach1']['size']>100*1024*1024){
				?>
				<script>
					alert("100MB 이상 파일은 올릴수가 없습니다.");
					history.back();
				</script>
				<?php 
				exit;
			}
			$file_ext = substr( strrchr($_FILES['attach1']['name'], "."),1);
			
			if(in_array(strtolower($file_ext), $img_no) || in_array(strtolower($file_ext), $mime_no)){
				?>
				<script>
					alert("FAILURE - FILE UPLOAD - 형식불가");
					//history.back();
				</script>
				<?php 
				exit;
			} 
	//		exit;			
			if(is_dir('files')&&(strtoupper($file_ext)=="ZIP" || strtoupper($file_ext)=="RAR" || strtoupper($file_ext)=="EGG" || strtoupper($file_ext)=="PDF" || strtoupper($file_ext)=="TXT" || strtoupper($file_ext)=="DOC" || strtoupper($file_ext)=="XLS" || strtoupper($file_ext)=="XLSX" || strtoupper($file_ext)=="PPT" || strtoupper($file_ext)=="PPTX" || strtoupper($file_ext)=="JPG" || strtoupper($file_ext)=="JPEG" || strtoupper($file_ext)=="GIF" || strtoupper($file_ext)=="PNG" || strtoupper($file_ext)=="BMP" )){
				move_uploaded_file($_FILES['attach1']['tmp_name'],"files/CS$date14.$file_ext");
			}else{
				?>
				<script>
					alert("FAILURE - FILE UPLOAD ");
					history.back();
				</script>
				<?php 
				exit;
			} 
			$attach1_= $_FILES['attach1']['name'];
			$attach1_m="files/CS$date14.$file_ext";
		}

	$op1 = addslashes($_POST['op1']);
	$op2 = addslashes($_POST['op2']);
	$op3 = addslashes($_POST['op3']);
	$op4 = addslashes($_POST['op4']);
	$op5 = addslashes($_POST['op5']);
	$op6 = str_replace(chr(13),"<br>",addslashes($_POST['op6']));

	if(!$op2 || !$op3 || !$op4 || !$op5 || !$op6){
		?>
		<script type="text/javascript">
		<!--
			alert("입력 안된 내용이 있습니다.");

			location.replace('mail.php');
			
		//-->
		</script>
		
		<?php 
			exit;
	}



	$op7 = str_replace(chr(13),"<br>",addslashes($_POST['op7']));
	$content = "
	<table style='width:100%;border-top:2px solid #494233;border-bottom:2px solid #494233;border-collapse:collapse;border-spacing:0;margin:0;padding:0;'>
		<tr>
			<td style='width:150px;text-align:center;font-weight:bold;height:40px;line-height:16px;background-color:#f8f3ec;border-top:1px solid #dedbd8;color:#494233;border:1px solid #dedbd8;'>신고유형</td>
			<td style='padding:0 0 0 10px;line-height:16px;height:40px;color:#494233;border:1px solid #dedbd8;'>$op1</td>
		</tr>
		<tr>
			<td style='width:150px;text-align:center;font-weight:bold;height:40px;line-height:16px;background-color:#f8f3ec;border-top:1px solid #dedbd8;color:#494233;border:1px solid #dedbd8;'>제목</td>
			<td style='padding:0 0 0 10px;line-height:16px;height:40px;color:#494233;border:1px solid #dedbd8;'>$op2</td>
		</tr>
		<tr>
			<td style='width:150px;text-align:center;font-weight:bold;height:40px;line-height:16px;background-color:#f8f3ec;border-top:1px solid #dedbd8;color:#494233;border:1px solid #dedbd8;'>누가</td>
			<td style='padding:0 0 0 10px;line-height:16px;height:40px;color:#494233;border:1px solid #dedbd8;'>$op3</td>
		</tr>
		<tr>
			<td style='width:150px;text-align:center;font-weight:bold;height:40px;line-height:16px;background-color:#f8f3ec;border-top:1px solid #dedbd8;color:#494233;border:1px solid #dedbd8;'>언제</td>
			<td style='padding:0 0 0 10px;line-height:16px;height:40px;color:#494233;border:1px solid #dedbd8;'>$op4</td>
		</tr>
		<tr>
			<td style='width:150px;text-align:center;font-weight:bold;height:40px;line-height:16px;background-color:#f8f3ec;border-top:1px solid #dedbd8;color:#494233;border:1px solid #dedbd8;'>어디서</td>
			<td style='padding:0 0 0 10px;line-height:16px;height:40px;color:#494233;border:1px solid #dedbd8;'>$op5</td>
		</tr>
		<tr>
			<td style='width:150px;text-align:center;font-weight:bold;height:40px;line-height:16px;background-color:#f8f3ec;border-top:1px solid #dedbd8;color:#494233;border:1px solid #dedbd8;'>내용</td>
			<td style='padding:0 0 0 10px;line-height:16px;height:40px;color:#494233;border:1px solid #dedbd8;'>$op6</td>
		</tr> ";
	if($op7){
		$content .="
		<tr>
			<td style='width:150px;text-align:center;font-weight:bold;height:40px;line-height:16px;background-color:#f8f3ec;border-top:1px solid #dedbd8;color:#494233;border:1px solid #dedbd8;'>이문제를 알고있는사람</td>
			<td style='padding:0 0 0 10px;line-height:16px;height:40px;color:#494233;border:1px solid #dedbd8;'>$op7</td>
		</tr>
	";
	}
	if($attach1_){
		$content .="
		<tr>
			<td style='width:150px;text-align:center;font-weight:bold;height:40px;line-height:16px;background-color:#f8f3ec;border-top:1px solid #dedbd8;color:#494233;border:1px solid #dedbd8;'>첨부파일</td>
			<td style='padding:0 0 0 10px;line-height:16px;height:40px;color:#494233;border:1px solid #dedbd8;'><a href='http://blog.yedaham.co.kr/mail/$attach1_m' target='_blank'>$attach1_</a></td>
		</tr>
	";
	}
	$content .="</table>";


	$t = mail($email ,$title ,$content, $add_mailheader);
	$t = mail($email2 ,$title ,$content, $add_mailheader);
	$t = mail($email3 ,$title ,$content, $add_mailheader);
	if($t){
		?>
		<script type="text/javascript">
		<!--
			alert("신고되었습니다.");
			location.replace('mail.php');
		//-->
		</script>
		<?php 
	}
	
} else {	//캡챠 실패시
  	echo '<script>
			alert(\'please check reCaptcha\');
			history.go(-1);
		  </script>';
}
?>
